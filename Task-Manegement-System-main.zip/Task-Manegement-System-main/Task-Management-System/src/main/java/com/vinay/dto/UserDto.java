//package com.vinay.dto;
//
//import java.util.List;
//
//import com.vinay.model.Task;
//
//import lombok.Data;
//
//@Data
//public class UserDto {
//	
//	private Long id;
//    private String email;
//    private String name;
//    private String password;
//    private String picture;
//    private List<Task> tasksOwned;
//
//}
